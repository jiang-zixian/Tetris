#include <iostream>
#include<graphics.h>
#include <windows.h>//����̨�����Ҫͷ�ļ�
#include <conio.h>//getch()����
#include <stdlib.h>//system()����
#include <time.h>
#include "3block.h"
#include "3operation.h"
using namespace std;
#define random(x) (rand()%x)


int main()
{
	//�������
	srand(time(0));

	doing DO;
	int height = DO.getHeight();
	int width = DO.getWidth();
	DO.welcome();
	DO.initGameSceen();

	/* ���Ƴ�ʼ��ͼ */
	int **map;
	map = (int**) new int*[height];

	/* ��ʼ����ͼ */
	for (int i = 0; i < height; i++)
	{
		*(map + i) = new int[width];
	}
	DO.initMap(map);
	DO.drawMap(map);

	/* ���Ʒ��� */
	int index = random(8);
	Block block;
	block.generate();
	block.set(1, 1, index);
	DO.drawBlock(block);

	/* ��һ������ */
	index = random(8);
	Block nextBlock;
	nextBlock.generate();
	nextBlock.set(1, 1, index);
	DO._drawPrompt(nextBlock);

	clock_t start, end;
	while (1)
	{
		start = clock();
		end = clock();

		while (end - start < DO.getSpeed())
		{
			if (DO._action(map, &block, -1) == 1)
			{
				while (DO.checkLine(map, height, width) == 1)
				{
					DO.cleanLine(map);
					DO.drawScore();
				}

				index = random(8);
				block.set(1,1, nextBlock.getType());
				DO.drawBlock(block);
				nextBlock.set(1, 1, index);
				DO._drawPrompt(nextBlock);

				// �������
				if (DO.checkCrash(map, &block) == 1) {
					break;
				}
			}
			end = clock();
		}
		// �������
		if (DO.checkCrash(map, &block) == 1) 
		{
			DO.fail();
			break;
		}
		if (DO._action(map, &block, 115) == 1) 
		{
			while (DO.checkLine(map, height, width) == 1) 
			{
				DO.cleanLine(map);
				DO.drawScore();
			}
			index = random(8);
			block.set(1, 1, nextBlock.getType());
			DO.drawBlock(block);
			nextBlock.set(1, 1, index);
			DO._drawPrompt(nextBlock);

			// �������
			if (DO.checkCrash(map, &block) == 1) 
			{
				DO.fail();
				break;
			}
		}
	}
	closegraph();
}