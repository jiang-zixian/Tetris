#include<stdio.h>
#include<graphics.h>
#include "3block.h"
#include "3operation.h"

int doing::checkCrash(int **map, Block *block)
{
	int x = block->x;
	int y = block->y;
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			if (block->shape[i][j] == 1)
			{
				if (x + i < 0 || x + i >= height || y + j < 0 || y + j >= width)
					return 1;
				if (map[x + i][y + j] != 8)
				{
					return 1;
				}
			}
			
		}
	}
	return 0;
}

int doing::_checkLine(int **map, int line, int width)
{
	for (int i = 0; i < width; i++)
	{
		if (map[line][i] == 8)
			return 0;
	}
	return 1;
}

int doing::checkLine(int **map, int height, int width)
{
	int indexL = -1;
	for (int i = 0; i < height; i++) 
	{
		if (_checkLine(map, i, width) == 1)
		{
			indexL = i;
			break;
		}
	}

	if (indexL != -1)
	{
		for (int i = indexL; i > 0; i--)
		{
			for (int j = 0; j < width; j++)
			{
				map[i][j] = map[i - 1][j];
			}
		}
	}
	else
	{
		return 0;
	}
	return 1;
}