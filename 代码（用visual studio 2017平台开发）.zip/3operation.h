#pragma once
#ifndef DOING_H
#define DOING_H
#include <iostream>
#include"3block.h"
#include<graphics.h>
using namespace std;

class doing
{
	int score;//���з���
	int rank;//���еȼ�=����%50
	int speed;
	int height;
	int width;
public:
	doing()
	{
		score = 0;
		rank = 0;
		speed = 500;
		height = 30;
		width = 15;
	}
	//���к����ӿ�
	int getScore()
	{
		return score;
	}
	int getRank()
	{
		return rank;
	}
	int getSpeed()
	{
		return speed;
	}
	int getHeight()
	{
		return height;
	}
	int getWidth()
	{
		return width;
	}

	//draw
	//void drawInit(int h, int w);
	void initMap(int **map);
	void drawMap(int **map);
	void drawBlock(Block block);
	void cleanBlock(Block blcok);
	void cleanPrompt();
	void addBlock(int **map, Block block);
	//void pos(int x, int y);
	void cleanLine(int **map);
	//void drawPrompt();
	void _drawPrompt(Block block);
	//void _drawNumber(int points[5][3], int x, int y);
	//void drawNumber(int number, int x, int y);
	void drawScore();
	void fail();


	//check
	int checkLine(int **map, int height, int width);
	int _checkLine(int **map, int line, int width);
	int checkCrash(int **map, Block *block);


	//action
	void getAction();
	int _move(int **map, Block *block, int x, int y, int sign);
	void rotation(Block *block, int director);
	void _transfer(int **map, Block *block, int sign);
	void transfer(int **map, Block *block);
	//void transfer(int **map, Block *block);
	int _action(int **map, Block *block, int c);

	//graph
	void welcome();
	void initGameSceen();
};

#endif // !DOING_H
